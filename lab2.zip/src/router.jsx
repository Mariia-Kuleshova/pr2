import { createBrowserRouter } from "react-router-dom";
import Home from "./pages/Home";
import Register from "./pages/Register";
import Participants from "./pages/Participants";
import NotFound from "./pages/NotFound";

//створення маршрутизації додатку
export const router = createBrowserRouter([
  { path: "/", element: <Home /> },
  { path: "/register/:eventId", element: <Register /> },
  { path: "/participants/:eventId", element: <Participants /> },

  { path: "*", element: <NotFound /> },
]);
